def new_week
	Week.create
end