class CreateHeroSelections < ActiveRecord::Migration
  def change
    create_table :hero_selections do |t|
      t.integer :first
      t.integer :second
      t.integer :third
      t.belongs_to :game

      t.timestamps null: false
    end
  end
end
