class DropTableHeroSelection < ActiveRecord::Migration
  def change
    drop_table :hero_selections
  end
end
