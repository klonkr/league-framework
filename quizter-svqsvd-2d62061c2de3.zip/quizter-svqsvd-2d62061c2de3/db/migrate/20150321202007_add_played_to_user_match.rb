class AddPlayedToUserMatch < ActiveRecord::Migration
  def change
    add_column :user_matches, :played, :boolean
  end
end
