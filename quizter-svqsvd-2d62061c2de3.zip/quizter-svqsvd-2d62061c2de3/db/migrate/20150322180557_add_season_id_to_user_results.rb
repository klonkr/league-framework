class AddSeasonIdToUserResults < ActiveRecord::Migration
  def change
    add_column :user_results, :season_id, :integer
  end
end
