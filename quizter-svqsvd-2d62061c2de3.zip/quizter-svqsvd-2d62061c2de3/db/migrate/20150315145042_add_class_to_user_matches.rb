class AddClassToUserMatches < ActiveRecord::Migration
  def change
    add_column :user_matches, :class, :integer
  end
end
