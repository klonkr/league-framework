class AddHomeToGame < ActiveRecord::Migration
  def change
    add_column :games, :home, :boolean
  end
end
