class CreateSeasonResults < ActiveRecord::Migration
  def change
    create_table :season_results do |t|
    	t.belongs_to :season

      t.timestamps null: false
    end
  end
end
