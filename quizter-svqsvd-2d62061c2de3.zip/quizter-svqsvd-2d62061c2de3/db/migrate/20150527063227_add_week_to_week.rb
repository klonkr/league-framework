class AddWeekToWeek < ActiveRecord::Migration
  def change
    add_column :weeks, :week, :integer
  end
end
