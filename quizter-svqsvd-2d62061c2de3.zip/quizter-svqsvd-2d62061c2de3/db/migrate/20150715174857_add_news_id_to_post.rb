class AddNewsIdToPost < ActiveRecord::Migration
  def change
    add_column :posts, :news_id, :integer
  end
end
