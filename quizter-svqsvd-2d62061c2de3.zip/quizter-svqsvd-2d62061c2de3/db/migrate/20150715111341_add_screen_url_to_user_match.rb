class AddScreenUrlToUserMatch < ActiveRecord::Migration
  def change
    add_column :user_matches, :screen_url, :string
  end
end
