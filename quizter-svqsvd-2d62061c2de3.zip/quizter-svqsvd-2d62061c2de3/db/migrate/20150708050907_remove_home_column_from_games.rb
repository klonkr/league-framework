class RemoveHomeColumnFromGames < ActiveRecord::Migration
  def change
    remove_column :games, :home
  end
end
