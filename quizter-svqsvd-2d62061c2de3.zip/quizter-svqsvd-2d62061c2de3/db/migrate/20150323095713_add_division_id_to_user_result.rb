class AddDivisionIdToUserResult < ActiveRecord::Migration
  def change
    add_column :user_results, :division_id, :integer
  end
end
