class AddResultToGame < ActiveRecord::Migration
  def change
    add_column :games, :result, :integer
  end
end
