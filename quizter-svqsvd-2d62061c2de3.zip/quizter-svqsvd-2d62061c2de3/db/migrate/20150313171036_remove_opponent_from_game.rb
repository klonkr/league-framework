class RemoveOpponentFromGame < ActiveRecord::Migration
  def change
  	remove_column :games, :opponent
  end
end
