class RenameFaultyHerosToCorrectHeroes < ActiveRecord::Migration
  def change
  	rename_table :heros, :heroes
  end
end
