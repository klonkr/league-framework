class AddColumnsToUsers < ActiveRecord::Migration
  def change
  	add_column :users, :battletag, :string, unique: true
  	add_column :users, :email, :string
  	add_column :users, :password_digest, :string
  	add_column :users, :remember_digest, :string
  	add_column :users, :admin, :boolean, default: false
  end
end
