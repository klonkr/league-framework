class AddMatchScreenToUserMatches < ActiveRecord::Migration
  def change
    add_column :user_matches, :match_screen, :string
  end
end
