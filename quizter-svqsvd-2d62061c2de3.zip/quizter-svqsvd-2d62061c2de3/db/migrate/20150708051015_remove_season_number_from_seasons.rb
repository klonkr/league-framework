class RemoveSeasonNumberFromSeasons < ActiveRecord::Migration
  def change
    remove_column :seasons, :season_number, :string
  end
end
