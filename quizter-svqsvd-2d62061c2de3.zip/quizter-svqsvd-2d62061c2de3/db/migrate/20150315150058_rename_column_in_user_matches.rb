class RenameColumnInUserMatches < ActiveRecord::Migration
  def change
  	rename_column :user_matches, :class, :playedClass
  end
end
