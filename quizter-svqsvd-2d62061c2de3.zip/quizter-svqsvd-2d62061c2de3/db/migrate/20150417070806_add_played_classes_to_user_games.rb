class AddPlayedClassesToUserGames < ActiveRecord::Migration
  def change
    add_column :user_games, :playedClasses, :integer, array: true, default: []
  end
end
