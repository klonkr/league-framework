class AddSeasonNumberToSeason < ActiveRecord::Migration
  def change
    add_column :seasons, :season_number, :integer
  end
end
