class AddInProgressToMatch < ActiveRecord::Migration
  def change
    add_column :matches, :in_progress, :boolean
  end
end
