class RemoveUclassFromMatch < ActiveRecord::Migration
  def change
  	remove_column :matches, :uclass
  	remove_column :matches, :oclass
  end
end
