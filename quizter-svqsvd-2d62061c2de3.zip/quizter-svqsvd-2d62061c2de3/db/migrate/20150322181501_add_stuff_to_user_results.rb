class AddStuffToUserResults < ActiveRecord::Migration
  def change
  	add_column :user_results, :played, :integer
  	add_column :user_results, :won, :integer
  	add_column :user_results, :drawn, :integer
  	add_column :user_results, :lost,  :integer
  	add_column :user_results, :matches_won, :integer
  	add_column :user_results, :matches_lost, :integer
  	add_column :user_results, :points, :integer
  end
end
