class AddSeasonNameToSeasons < ActiveRecord::Migration
  def change
    add_column :seasons, :season_name, :string
  end
end
