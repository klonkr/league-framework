class RemoveMatchScreenFromMatches < ActiveRecord::Migration
  def change
    remove_column :matches, :match_screen
  end
end
