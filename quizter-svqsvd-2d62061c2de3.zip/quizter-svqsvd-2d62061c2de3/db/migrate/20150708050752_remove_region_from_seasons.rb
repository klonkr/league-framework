class RemoveRegionFromSeasons < ActiveRecord::Migration
  def change
    remove_column :seasons, :region
  end
end
