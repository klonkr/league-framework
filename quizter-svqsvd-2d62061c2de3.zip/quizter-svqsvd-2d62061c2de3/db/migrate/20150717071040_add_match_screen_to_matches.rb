class AddMatchScreenToMatches < ActiveRecord::Migration
  def change
    add_column :matches, :match_screen, :string
  end
end
