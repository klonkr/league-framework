class RemoveColumnsSeasonNumberAndRegionFromSeasons < ActiveRecord::Migration
  def change
    remove_column :seasons, :season_number, :string
    remove_column :seasons, :region, :string
  end
end
