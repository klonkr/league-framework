class AddUserIdToHeroSelection < ActiveRecord::Migration
  def change
    add_column :hero_selections, :user_id, :integer
  end
end
