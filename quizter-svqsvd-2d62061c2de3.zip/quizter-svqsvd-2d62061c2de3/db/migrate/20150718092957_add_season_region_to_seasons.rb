class AddSeasonRegionToSeasons < ActiveRecord::Migration
  def change
    add_column :seasons, :region, :string
  end
end
