class AddClasToMatch < ActiveRecord::Migration
  def change
    add_column :matches, :uclass, :string
    add_column :matches, :oclass, :string
  end
end
