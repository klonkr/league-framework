class AddInProgressToUserMatches < ActiveRecord::Migration
  def change
    add_column :user_matches, :in_progress, :boolean
  end
end
