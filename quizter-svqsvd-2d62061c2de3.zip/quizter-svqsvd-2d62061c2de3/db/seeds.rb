# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)

Hero.create(hero: "druid")
Hero.create(hero: "hunter")
Hero.create(hero: "mage")
Hero.create(hero: "paladin")
Hero.create(hero: "priest")
Hero.create(hero: "rogue")
Hero.create(hero: "shaman")
Hero.create(hero: "warlock")
Hero.create(hero: "warrior")
