# encoding: UTF-8
# This file is auto-generated from the current state of the database. Instead
# of editing this file, please use the migrations feature of Active Record to
# incrementally modify your database, and then regenerate this schema definition.
#
# Note that this schema.rb definition is the authoritative source for your
# database schema. If you need to create the application database on another
# system, you should be using db:schema:load, not running all the migrations
# from scratch. The latter is a flawed and unsustainable approach (the more migrations
# you'll amass, the slower it'll run and the greater likelihood for issues).
#
# It's strongly recommended that you check this file into your version control system.

ActiveRecord::Schema.define(version: 20150718110023) do

  # These are extensions that must be enabled in order to support this database
  enable_extension "plpgsql"

  create_table "divisions", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "games", force: :cascade do |t|
    t.integer  "season_id"
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "result"
    t.integer  "week"
    t.string   "region"
    t.integer  "division_id"
  end

  add_index "games", ["season_id"], name: "index_games_on_season_id", using: :btree

  create_table "heros", force: :cascade do |t|
    t.string   "hero"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "invitations", force: :cascade do |t|
    t.string   "code"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.boolean  "used"
  end

  create_table "matches", force: :cascade do |t|
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.integer  "user_id"
    t.integer  "game_id"
    t.boolean  "played"
    t.integer  "winner"
    t.boolean  "in_progress"
  end

  create_table "news", force: :cascade do |t|
    t.string   "title"
    t.string   "body"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "news_comments", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "news_id"
    t.string   "body"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "posts", force: :cascade do |t|
    t.integer  "user_id"
    t.string   "body"
    t.integer  "game_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "news_id"
  end

  add_index "posts", ["game_id"], name: "index_posts_on_game_id", using: :btree

  create_table "season_results", force: :cascade do |t|
    t.integer  "season_id"
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
  end

  create_table "seasons", force: :cascade do |t|
    t.datetime "created_at",  null: false
    t.datetime "updated_at",  null: false
    t.string   "season_name"
  end

  create_table "user_games", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "game_id"
    t.datetime "created_at",                 null: false
    t.datetime "updated_at",                 null: false
    t.integer  "playedClasses", default: [],              array: true
  end

  add_index "user_games", ["game_id"], name: "index_user_games_on_game_id", using: :btree
  add_index "user_games", ["user_id"], name: "index_user_games_on_user_id", using: :btree

  create_table "user_matches", force: :cascade do |t|
    t.integer  "user_id"
    t.integer  "match_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.integer  "playedClass"
    t.boolean  "played"
    t.boolean  "in_progress"
    t.string   "screen_url"
    t.string   "match_screen"
  end

  add_index "user_matches", ["match_id"], name: "index_user_matches_on_match_id", using: :btree
  add_index "user_matches", ["user_id"], name: "index_user_matches_on_user_id", using: :btree

  create_table "user_results", force: :cascade do |t|
    t.integer  "user_id"
    t.datetime "created_at",   null: false
    t.datetime "updated_at",   null: false
    t.integer  "season_id"
    t.integer  "played"
    t.integer  "won"
    t.integer  "drawn"
    t.integer  "lost"
    t.integer  "matches_won"
    t.integer  "matches_lost"
    t.integer  "points"
    t.integer  "division_id"
  end

  create_table "users", force: :cascade do |t|
    t.datetime "created_at",                      null: false
    t.datetime "updated_at",                      null: false
    t.integer  "division_id"
    t.string   "username"
    t.string   "battletag"
    t.string   "email"
    t.string   "password_digest"
    t.string   "remember_digest"
    t.boolean  "admin",           default: false
    t.integer  "code"
    t.string   "region"
    t.string   "avatar_url"
  end

  create_table "weeks", force: :cascade do |t|
    t.datetime "created_at", null: false
    t.datetime "updated_at", null: false
    t.integer  "week"
  end

end
