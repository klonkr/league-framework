@match = Match.find(params[:id])
@game = @match.game
@homeUser = @match.users.order("user_matches.id ASC").take(2).first
@awayUser = @match.users.order("user_matches.id ASC").take(2).last
@season = Season.last
userResults = UserResult.all.where(season_id: @season.id)
@homeUsersMatch = @match.user_matches.order("id ASC").first
@awayUsersMatch = @match.user_matches.order("id ASC").last

if @match.update_attributes(match_params)

  if @match.played == true
    homeUserGame = @game.user_games.order("user_id ASC").take(2).first
    awayUserGame = @game.user_games.order("user_id ASC").take(2).last

    selected_heroes(homeUserGame, @homeUsersMatch)
    selected_heroes(awayUserGame, @awayUsersMatch)
  end


  if @match.id == @game.matches.order("id ASC").last.id && @match.played == true
    winner = Array.new
    homeWins = Array.new
    awayWins = Array.new
    @game.matches.order("id ASC").each do |match|
      winner.push(match.winner)
    end

    winner.each do |win|
      if win == @homeUser.id
        homeWins.push(win)
      end
      if win == @awayUser.id
        awayWins.push(win)
      end
    end

    homeGame = userResults.find_by(user_id: @homeUser.id)
    awayGame = userResults.find_by(user_id: @awayUser.id)

    if homeWins.count > awayWins.count
      @game.update(result: @homeUser.id)
      update_score("won", homeGame, homeWins.count, awayWins.count)
      update_score("lost", awayGame, awayWins.count, homeWins.count)

    end
    if awayWins.count > homeWins.count
      @game.update(result: @awayUser.id)
      update_score("lost", homeGame, homeWins.count, awayWins.count)
      update_score("won", awayGame, awayWins.count, homeWins.count)

    end
    if homeWins.count == awayWins.count
      @game.update(result: 0)
      update_score("drawn", homeGame, homeWins.count, awayWins.count)
      update_score("drawn", awayGame, awayWins.count, homeWins.count)
    end
  end
  redirect_to @match
else
  redirect_to root
end
