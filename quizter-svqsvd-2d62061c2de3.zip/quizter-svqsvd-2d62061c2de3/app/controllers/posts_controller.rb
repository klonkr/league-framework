class PostsController < ApplicationController
  def new
    @post = Post.new
  end

  def create
    @post = Post.new(post_params)

    if @post.save
      flash[:notice] = "Comment successfully posted!"
      redirect_to(:back)
    else
      flash[:error] = "Comment not posted."
    end
  end

  def edit
  end

  def update
  end

  def delete
  end

  private

    def post_params
      params.require(:post).permit(:body, :user_id, :game_id, :news_id)
    end
end
