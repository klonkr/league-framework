# handles creation of Seasons
class SeasonsController < ApplicationController
  before_action :require_admin, only: :new

  def new
    @season = Season.new
  end

  def create
    regions = %w(EU US)

    @season = Season.new(season_params)
    if @season.save
      regions.each do |region|
        flash[:success] = 'New Season created!'

        divisions = Division.all 			# gets all divisions
        users = User.all.where(region: region)					# gets all users

        divisions.each do |division| 		# for each division
          users_in_div = division.users.all # get all users in each division
          users_in_div_in_region = users_in_div.where(region: region)

          home = []			# create a new array that will
                        # hold the home teams id
          users_in_div_in_region.each do |user|		# Gets all the users and
            home.push(user)				# pushes them into the array
            user.user_results.create(
              division_id: division.id,
              season_id: @season.id,
              played: 0,
              won: 0,
              drawn: 0,
              lost: 0,
              matches_won: 0,
              matches_lost: 0,
              points: 0)
          end # users_in_div_region end

          player1 = home.shuffle			# shuffles the home-array

          away = []				# will lead to a copy of the
                           # player1-array, but just
          player1.each do |user|			# hold the users id's
            away.push(user.id)
          end # player1.each end

          count = home.count - 2			# "calculate" how many weeks
                           # are needed
          week = []
          for i in 0..count
            week[i] = i + 1				# creates a week array
            i += 1
          end # for end

          n = 0

          player1.each do |user|			# for each (shuffled) user
            n += 1						# creates an array called
            matches = [] 		# matches which holds their
            matches.push(user.id)		# opponents ID

            rotate = away.rotate(n)		# rotates the array 1 step
            matches.concat(rotate)		# for each user

            matches.delete_if do |a|    # delets the users own ID
              a == user.id 			# from the array
            end # match delete end

            counter = 0
            week.each do |week|			# for each week
              opponent = users_in_div.find(matches[counter])
              user.games.create(
                week: week,
                season_id: @season.id,
                region: region,
                division_id: division.id)

              last_game = Game.last

              3.times do
                user.matches.create(game_id: last_game.id)
                last_match = Match.last
                opponent.user_matches.create(match_id: last_match.id)
              end # 3 times do end

              opponent.user_games.create(game_id: last_game.id)
              counter += 1
            end # player1 end
          end # division.each end
        end # region.each end
      end # if season save end
    end # create end

    redirect_to @season
  end

  def index
    @seasons = Season.all
  end

  def schedule
    @divisions = Division.all
    @season = Season.last
    @divisions = Division.all
    @games = @season.games.all
    @regions = %w(EU US)

    @eu_games = Game.all.where(region: 'EU').where(season_id: @season.id)
    @us_games = Game.all.where(region: 'US').where(season_id: @season.id)

    @weeks = []

    unless @games.blank?
      number = Game.where(season_id: Season.last).last.week

      number.times do |i|
        @weeks.push(i + 1)
      end
    end
  end

  def show
    @divisions = Division.all
    @season = Season.find(params[:id])
    @games = Game.where(season_id: @season.id)
    @eu_users = User.all.where(region: 'EU')
    @us_users = User.all.where(region: 'US')
    @regions = %w(EU US)

    eu_ids = @eu_users.pluck(:id)
    us_ids = @us_users.pluck(:id)

    @eu_user_results = UserResult
      .all
      .where(user_id: eu_ids)
      .where(season_id: @season.id)
    @us_user_results = UserResult.all.where(user_id: us_ids)
    .where(season_id: @season.id)
  end

  private

  def season_params
    params.require(:season).permit(:season_name)
  end

  def require_admin
    unless current_user.admin == true
    flash[:error] = 'You must be an admin for that.'
    redirect_to root_url
  end
  end
end
