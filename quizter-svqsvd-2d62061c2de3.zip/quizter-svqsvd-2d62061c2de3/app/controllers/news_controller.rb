class NewsController < ApplicationController
  before_action :require_admin, only: [:new, :edit]

  def index
    @news = News.all
  end

  def new
  	@news = News.new
  end

  def create
    @news = News.new(news_params)

    if @news.save
      flash[:success] = "News item created successfully!"
      redirect_to @news
    else
      flash[:error] = "News item not created."
    end
  end

  def show
    @news = News.find(params[:id])
    @post = Post.new
    @posts = Post.where(news_id: params[:id])
    @users = User.all

  end

  def update
  end

  def edit
  end

  private

  def news_params
    params.require(:news).permit(:title, :body)
  end

  def require_admin
    unless current_user.admin == true
      flash[:error] = "You must be an admin for that."
      redirect_to root_url
    end
  end
end
