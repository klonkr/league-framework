class MatchesController < ApplicationController
  include MatchesHelper
  def show

  	@match = Match.find(params[:id])
    @week = Week.last
    @homeUsersMatch = @match.user_matches.order("id ASC").first
    @awayUsersMatch = @match.user_matches.order("id ASC").last
    @game = @match.game
  	@users = @match.users.all
    @homeUser = @match.users.order("user_matches.id ASC").take(2).first
    @awayUser = @match.users.order("user_matches.id ASC").take(2).last
  	@heroes = Hero.all

  end

  def update
    @match = Match.find(params[:id])
    @homeUser = @match.users.order("user_matches.id ASC").take(2).first
    @awayUser = @match.users.order("user_matches.id ASC").take(2).last
    users = @match.users.all
    logger.debug "current match: #{@match.id}"
    if @match.update(match_params)
      logger.debug "current match: #{@match.id}"

      selected_heroes(@match.game.user_games.find_by(user_id: @homeUser.id), @match.user_matches.find_by(user_id: @homeUser.id))
      selected_heroes(@match.game.user_games.find_by(user_id: @awayUser.id), @match.user_matches.find_by(user_id: @awayUser.id))


      if @match.id == Game.find(@match.game.id).matches.last.id
        logger.debug "current match: #{@match.id}"
        homeUser = @match.users.order("user_matches.id ASC").take(2).first
        awayUser = @match.users.order("user_matches.id ASC").take(2).last
        Match.assign_winner(homeUser, awayUser, @match.game)
        users.each do |user|
          Match.calculate_score(user, Season.last)
        end               # users in match .each end
        redirect_to @match.game
      else
        redirect_to @match.game
      end                 # if last match in game end
    else
      if correct_week(@match) == true
        if prev_match_played(@match) == true
          flash[:success] = "Correct match"
        elsif prev_match_played(@match) == false
          flash[:warning] = "Previous match has not yet been completed."
        end               # if prev match end
      elsif correct_week(@match) == false
        flash[:warning] = "You can't play this match yet."
      end                 # if correct week end

      redirect_to @match.game
    end                   # if match saved end
  end                     # def end

  def edit
    @match = Match.find(params[:id])
    @game = @match.game
    @prevMatch = previous_match(@game, @match)
    @users = @match.users.all
    @heroes = Hero.all
    @homeUsersMatch = @match.user_matches.order("id ASC").first
    @awayUsersMatch = @match.user_matches.order("id ASC").last
    @homeUser = @match.users.order("user_matches.id ASC").take(2).first
    @awayUser = @match.users.order("user_matches.id ASC").take(2).last
    @unavailableHomeHeroes = heroes_unavailable(@heroes, @game, @homeUser)
    @unavailableAwayHeroes = heroes_unavailable(@heroes, @game, @awayUser)
    @s3_direct_post = S3_BUCKET.presigned_post(key: "uploads/#{SecureRandom.uuid}/${filename}", success_action_status: 201, acl: :public_read)
  end

  private

  def match_params
  	params.require(:match).permit(:winner, :played, :in_progress, user_matches_attributes: [:id, :playedClass, :in_progress, :played, :match_screen], game_attributes: :result, user_result_attributes: [:won, :drawn, :lost, :matches_won, :matches_lost, :points])
  end
end
