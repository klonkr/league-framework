class UsersController < ApplicationController
  before_action :logged_in_user, only: [:index, :edit, :update]
  before_action :correct_user,   only: [:edit, :update]

  def index
    @users = User.paginate(page: params[:page])
  end

  def new
  	@user = User.new
  end

  def show
    @users = User.all
  	@user = User.find(params[:id])
  	@games = @user.games.all
    @wins = @games.all.where(result: @user.id).count
    @draws = @games.all.where(result: 0).count
    @losses = @games.where('result not in (?)', [0, @user.id]).count
  end

  def create
  	@user = User.new(user_params)
    invitations = Invitation.all

    cleared = false
    claimed = false

    invitations.each do |invite|
      if params[:user][:code] == invite.code && invite.used == false
        cleared = true
        claimed = invite
      end
    end

  	if cleared == true && @user.save

      claimed.update_columns(used: true)
      log_in @user
  		flash[:success] = "Welcome to HSLEAGUE"
  		redirect_to @user
  	else
      flash[:warning] = "Invalid or already used code."
  		render 'new'
  	end
  end

  def edit
    @user = User.find(params[:d])
  end

  def update
    @user = User.find(params[:id])
    if @user.update_attributes(user_params)
      flash[:success] = "Profile updated"
      redirect_to @user
    else
      render 'edit'
    end
  end

  private

  	def user_params
  		params.require(:user).permit(:username, :battletag, :email, :password, :password_confirmation, :code, :region)
  	end

    def logged_in_user
      unless logged_in?
        store_location
        flash[:danger] = "Please log in"
        redirect_to login_url
      end
    end

    def correct_user
      @user = User.find(params[:id])
      redirect_to(root_url) unless current_user?(@user)
    end

end
