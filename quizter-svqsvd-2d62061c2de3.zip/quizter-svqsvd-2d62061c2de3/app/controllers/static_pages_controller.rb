class StaticPagesController < ApplicationController
	def about
	end

	def contact
	end

	def rules
	end

	def home
		@news = News.all
	end

	def todo
	end
end
