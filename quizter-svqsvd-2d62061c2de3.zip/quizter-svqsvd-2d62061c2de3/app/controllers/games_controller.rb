class GamesController < ApplicationController
  def show
  	@game = Game.find(params[:id])
  	@users = @game.users.all
  	@matches = @game.matches.all
  	@week = [1,2,3,4,5,6,7]
  	@heroes = Hero.all
    @post = Post.new
    @allUsers = User.all
  end
end
