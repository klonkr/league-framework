# helper for MarchesController.rb
module MatchesHelper

  # updates a users score after a game is finished
  def update_score(result, userResult, homeWins, awayWins)
    results = userResult.serializable_hash
    if results["played"].present? then results["played"] += 1 end
    if results[result].present? then results[result] += 1 end
    if results["matches_won"].present? then results["matches_won"] += homeWins end
    if results["matches_lost"].present? then results["matches_lost"] += awayWins end

    case result

    when "won"
      if results["points"].present? then results["points"] += 3 end

    when "drawn"
      if results["points"].present? then results["points"] += 1 end
    when "lost"
      if results["points"].present? then results["points"] += 0 end
    end

    userResult.update_all(	played: results["played"],
              won: results["won"],
              drawn: results["drawn"],
              lost: results["lost"],
              matches_won: results["matches_won"],
              matches_lost: results["matches_lost"],
              points: results["points"])


  end

  # takes a game and a match from this game, and spits out the previous match if there is one
  def previous_match(matchGame, match)
    game = matchGame

    prevMatch = nil

    game.matches.each do |gameMatch|
      if gameMatch.id == match.id - 1
        prevMatch = gameMatch
      end
    end

    return prevMatch

  end

  def prev_match_played(match)
    if match.game.matches.first == match.id
      return true
    else
      prevMatch = previous_match(match.game, match)
      if prevMatch == true
        return true
      else
        return false
      end
    end
  end

  def correct_week(match)
    if match.game.week == Week.last.week
      return true
    else
      return false
    end
  end


  def next_match(match)
    if match.game.matches.last.id == match.id
      return false
    else
      return Match.find(match.id + 1)
    end
  end

  def available_heroes(heroes, array)
    available_heroes = Hash.new
    heroes.each do |hero|
      if !hero.id.in?(array)
        available_heroes[hero.hero] = hero.id
      end
    end
    return available_heroes
  end

  def heroes_unavailable(heroes, game, user)
    heroes_unavailable = []
    matches = game.matches.all
    matches.each do |match|

      if match.winner == user.id
        heroes_unavailable.push(match.user_matches.find_by(user_id: user.id).playedClass)
      end
    end

    available_heroes = Hash.new
    heroes.each do |hero|
      if !hero.id.in?(heroes_unavailable)
        available_heroes[hero.hero] = hero.id
      end
    end

    return available_heroes
  end

  def participant()
    if current_user.present?
      if current_user.id == @users.first.id || current_user.id == @users.last.id
        participant = true
      else
        participant = false
      end
    end
  end

  def selected_heroes(userGame, userMatch)
    game = userGame
    match = userMatch

    if game.playedClasses.last != match.playedClass
          game.playedClasses.push(match.playedClass)
          game.save
      end
  end

end
