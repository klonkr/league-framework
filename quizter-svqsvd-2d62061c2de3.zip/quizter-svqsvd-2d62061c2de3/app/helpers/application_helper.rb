module ApplicationHelper
  def full_title(page_title = '')
    base_title = "HSLEAGUE"
    if page_title.empty?
      base_title
    else
      "#{page_title} | #{base_title}"
    end
  end

  def markdown(text)
    options = {
      filter_html:     true,
      hard_wrap:       true,
      link_attributes: { rel: 'nofollow', target: "_blank" },
      space_after_headers: true,
      fenced_code_blocks: true
    }

    extensions = {
      autolink:           true,
      superscript:        true,
      disable_indented_code_blocks: true
    }

    renderer = Redcarpet::Render::HTML.new(options)
    markdown = Redcarpet::Markdown.new(renderer, extensions)

    markdown.render(text).html_safe
  end

  def battletag_or_username(user)
    if !current_user.nil?
      user.battletag
    else
      user.username
    end
  end

  def calculate_score1(user, season)
    played = 0
    won = 0
    drawn = 0
    lost = 0
    matches_won = 0
    matches_lost = 0
    points = 0

    userGames = user.games.where(season_id: season.id)

    userGames.each do |game|
      played += 1
      if game.result == user.id
        won += 1
        points += 3
      elsif game.result == 0 && game.result != user.id
        lost += 1
        points += 0
      elsif game.result == 0
        drawn += 1
        points += 1
      end

      game.matches.all.each do |match|
        if match.winner == user.id
          matches_won += 1
        else
          matches_lost += 1
        end
      end
    end

    userResult = UserResult.find_by(user_id: user.id, season_id: season.id)

    userResult.update(	played: played,
                        won: won,
                        drawn: drawn,
                        lost: lost,
                        matches_won: matches_won,
                        matches_lost: matches_lost,
                        points: points )
  end
end
