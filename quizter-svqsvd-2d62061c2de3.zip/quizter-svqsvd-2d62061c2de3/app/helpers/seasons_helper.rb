module SeasonsHelper
  def get_score(user, season)
    result = { played: nil, won: nil, drawn: nil, lost: nil, MW: nil, ML: nil, MNminusML: nil, points: nil }
    played, won, drawn, lost, mw, ml, mwMinusMl, points = nil
    games = Game.where(season_id: season.id)

    userGames = Array.new

    games.each do |game|
      if game.user_games.find_by_user_id(user.id) != nil
        if game.user_games.find_by(user_id: user.id).user.id == user.id
          userGames.push(game)
        end

      end

    end
  end
end
