class Match < ActiveRecord::Base
	include MatchesHelper
	include SessionsHelper
	include ApplicationHelper


	belongs_to :game
	has_many :user_matches
	has_many :users, :through => :user_matches
	accepts_nested_attributes_for :user_matches

	before_update :prev_match_played, :correct_week
	after_update :check_in_progress

	private

		def correct_week
			if self.game.week == Week.last.week
				return true
			else
				return false
			end
		end

		def self.assign_winner(homeUser, awayUser, game)
			winner = Array.new
	    homeWins = Array.new
	    awayWins = Array.new
	    game.matches.order("id ASC").each do |match|
	      winner.push(match.winner)
	    end

	    winner.each do |win|
	      if win == homeUser.id
	        homeWins.push(win)
	      end
	      if win == awayUser.id
	        awayWins.push(win)
	      end
	    end

	    if homeWins.count > awayWins.count
	      game.update(result: homeUser.id)

	    elsif awayWins.count > homeWins.count
	      game.update(result: awayUser.id)

	    else
				homeWins.count == awayWins.count
	      game.update(result: 0)
	    end
		end

		def check_in_progress
			if self.in_progress.blank? && self.played == nil
				if self.user_matches.order("user_matches ASC").take(2).first.in_progress == true && self.user_matches.order("user_matches ASC").take(2).last.in_progress == true
					self.update(in_progress: true)
				end
			end
		end

		def self.calculate_score(user, season)
			played = 0
			won = 0
			drawn = 0
			lost = 0
			matches_won = 0
			matches_lost = 0
			points = 0

			userGames = user.games.where(season_id: season.id)

			userGames.each do |game|
				if game.result.present?
					played += 1
					if game.result == user.id
						won += 1
						points += 3
					elsif game.result == 0
						drawn += 1
						points += 1
					else
						lost += 1
						points += 0
					end

					game.matches.all.each do |match|
						if match.winner == user.id
							matches_won += 1
						elsif match.winner == 0
						else
							matches_lost += 1
						end
					end
				end
			end

			userResult = UserResult.find_by(user_id: user.id, season_id: season.id)

			userResult.update(	played: played,
													won: won,
													drawn: drawn,
													lost: lost,
													matches_won: matches_won,
													matches_lost: matches_lost,
													points: points )

			results = { played: played,
													won: won,
													drawn: drawn,
													lost: lost,
													matches_won: matches_won,
													matches_lost: matches_lost,
													points: points }
			return results
		end

		def prev_match_played
			if self.game.matches.first.id == self.id
				return true
			else
				prevMatch = previous_match(self.game, self)
				if prevMatch.played == true
					return true
				else
					return false
				end
			end
		end
end
