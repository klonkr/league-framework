class UserResult < ActiveRecord::Base
	has_one :user
	has_one :season

	def init
		self.played ||= 0.0
		self.won ||= 0.0
		self.drawn ||= 0.0
		self.lost ||= 0.0
		self.matches_won ||= 0.0
		self.matches_lost ||= 0.0
		self.points ||= 0.0
	end
end
