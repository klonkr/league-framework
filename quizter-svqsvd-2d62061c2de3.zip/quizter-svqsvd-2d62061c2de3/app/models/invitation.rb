class Invitation < ActiveRecord::Base
end
