class Game < ActiveRecord::Base
	belongs_to :season
	has_many :matches
	has_many :user_games
	has_many :users, :through => :user_games
	has_many :posts
end
