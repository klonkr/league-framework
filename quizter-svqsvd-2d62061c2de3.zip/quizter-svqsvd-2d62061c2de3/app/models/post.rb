class Post < ActiveRecord::Base
  belongs_to :game
end
