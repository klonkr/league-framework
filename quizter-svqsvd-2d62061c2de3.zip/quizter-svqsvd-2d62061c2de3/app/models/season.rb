class Season < ActiveRecord::Base
	has_many :games
	has_many :user_results
	has_one :season_result
end
