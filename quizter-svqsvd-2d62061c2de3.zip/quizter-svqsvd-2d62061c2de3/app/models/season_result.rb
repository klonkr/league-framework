class SeasonResult < ActiveRecord::Base
	belongs_to :season
end
