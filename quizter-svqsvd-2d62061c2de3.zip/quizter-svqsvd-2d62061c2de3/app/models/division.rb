class Division < ActiveRecord::Base
	has_many :users
end
