class Hero < ActiveRecord::Base

end
