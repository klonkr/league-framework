class Week < ActiveRecord::Base
	def new_week
		Week.create
	end
end
