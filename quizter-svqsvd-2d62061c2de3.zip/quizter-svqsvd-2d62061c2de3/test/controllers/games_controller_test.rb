require 'test_helper'

class GamesControllerTest < ActionController::TestCase

	test "should show and its associated matches" do
		get :show, id: games(:one).id
		assert_response :success
	end
end
