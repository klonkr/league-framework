require 'test_helper'

class MatchesControllerTest < ActionController::TestCase

end
