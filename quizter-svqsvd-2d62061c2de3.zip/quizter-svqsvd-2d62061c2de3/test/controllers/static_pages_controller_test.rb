require 'test_helper'

class StaticPagesControllerTest < ActionController::TestCase
	test "should return about" do
		get :about
		assert_response :success
	end

	test "should return contact" do
		get :contact
		assert_response :success
	end

	test "should return home" do
		get :about
		assert_response :success
	end

	test "should return help" do
		get :help
		assert_response :success
	end

	test "should get todo" do
		get :todo
		assert_response :success
	end
end
