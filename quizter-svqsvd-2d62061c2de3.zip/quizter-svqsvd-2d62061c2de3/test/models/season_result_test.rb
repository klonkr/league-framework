require 'test_helper'

class SeasonResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
