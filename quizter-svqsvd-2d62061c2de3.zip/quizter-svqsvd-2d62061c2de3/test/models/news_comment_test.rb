require 'test_helper'

class NewsCommentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
