require 'test_helper'

class UserMatchTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
