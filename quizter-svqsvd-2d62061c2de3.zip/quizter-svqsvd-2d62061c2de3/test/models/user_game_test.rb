require 'test_helper'

class UserGameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
