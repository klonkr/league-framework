def new_week
	week = Week.create
	echo week
end